import mongoose from 'mongoose';

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true },
    role: { type: String, default: 'user' },
    provider: { type: String, default: 'credentials' },
  },
  { timestamps: true } // gives you createdAt / updatedAt automatically
);

// Prevents "Cannot overwrite model" errors during Next.js dev hot-reloads
export default mongoose.models.User || mongoose.model('User', userSchema);
