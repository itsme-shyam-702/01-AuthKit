# AuthKit — JWT Auth System

A complete JWT authentication system built with Next.js 14 and MongoDB.

## Features
- Register & login with JWT tokens stored in httpOnly cookies
- Users persisted in MongoDB via Mongoose (not in-memory — survives restarts)
- Protected dashboard and profile routes
- Public Home / About / Contact pages, plus an account menu with Logout
- bcrypt password hashing
- useContext for auth state across app
- Zod validation on forms and API routes

## Tech Stack
- **Next.js 14** (App Router)
- **MongoDB + Mongoose** — persistent user storage
- **JWT (jsonwebtoken)** — token sign/verify
- **bcryptjs** — password hashing
- **React Hook Form + Zod** — form validation
- **useContext** — auth state
- **Tailwind CSS** — styling

## Getting Started
```bash
npm install
cp .env.example .env.local
# Edit .env.local with your own MONGODB_URI and JWT_SECRET
npm run dev
```

There's no seeded/demo account anymore since users now live in MongoDB —
just register a new account from `/register` and log in with it.

## Routes
- `/` — Landing page
- `/about` — About page
- `/contact` — Contact page
- `/login` — Login page
- `/register` — Register page
- `/dashboard` — Protected dashboard
- `/profile` — Protected, view-only profile page
- `/api/auth/register` — POST register
- `/api/auth/login` — POST login / DELETE logout
- `/api/auth/me` — GET current user

