'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Shield, LayoutDashboard, User, Home, Info, Mail, LogOut, FolderOpen, Users, CheckSquare, TrendingUp } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

export default function DashboardPage() {
  const { user, loading, logout } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) router.push('/login');
  }, [user, loading, router]);

  if (loading || !user) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
    </div>
  );

  const initials = user.name?.split(' ').map(n => n[0]).join('').slice(0, 2) || 'JD';

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className="w-56 bg-white border-r border-gray-100 flex flex-col">
        <div className="p-5 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center">
              <Shield size={14} className="text-white" />
            </div>
            <span className="font-semibold text-gray-900">AuthKit</span>
          </div>
        </div>
        <nav className="flex-1 p-4 space-y-1">
          <Link href="/dashboard" className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-primary/10 text-primary text-sm font-medium">
            <LayoutDashboard size={16} /> Overview
          </Link>
          <Link href="/profile" className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-50 text-sm">
            <User size={16} /> Profile
          </Link>
          <Link href="/" className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-50 text-sm">
            <Home size={16} /> Home
          </Link>
          <Link href="/about" className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-50 text-sm">
            <Info size={16} /> About
          </Link>
          <Link href="/contact" className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-50 text-sm">
            <Mail size={16} /> Contact
          </Link>
        </nav>
        <div className="p-4 border-t border-gray-100">
          <button onClick={logout} className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-red-500 hover:bg-red-50 text-sm w-full">
            <LogOut size={16} /> Logout
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 p-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-500 text-sm">Welcome back, {user.name} 👋</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center text-primary font-semibold text-sm">
              {initials}
            </div>
            <span className="text-sm font-medium text-gray-700">{user.name}</span>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          {[
            { icon: FolderOpen, label: 'Total Projects', value: '1', color: 'text-blue-500 bg-blue-50' },
            { icon: Users, label: 'Team Members', value: '3', color: 'text-purple-500 bg-purple-50' },
            { icon: CheckSquare, label: 'Tasks Completed', value: '12', color: 'text-green-500 bg-green-50' },
            { icon: TrendingUp, label: 'Success Rate', value: '98%', color: 'text-orange-500 bg-orange-50' },
          ].map(({ icon: Icon, label, value, color }) => (
            <div key={label} className="bg-white rounded-xl border border-gray-100 p-5">
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${color}`}>
                <Icon size={18} />
              </div>
              <div className="text-2xl font-bold text-gray-900">{value}</div>
              <div className="text-xs text-gray-500 mt-0.5">{label}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-6">
          {/* Recent Activity */}
          <div className="bg-white rounded-xl border border-gray-100 p-5">
            <h2 className="font-semibold text-gray-900 mb-4">Recent Activity</h2>
            <div className="space-y-3">
              {[
                { action: 'Logged in successfully', time: '2 min ago', icon: CheckSquare },
                { action: 'Updated profile information', time: '1 day ago', icon: User },
                { action: 'Changed password', time: '3 days ago', icon: Shield },
              ].map(({ action, time, icon: Icon }) => (
                <div key={action} className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gray-50 rounded-lg flex items-center justify-center">
                    <Icon size={14} className="text-gray-500" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-700">{action}</p>
                  </div>
                  <span className="text-xs text-gray-400">{time}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Profile Summary */}
          <div className="bg-white rounded-xl border border-gray-100 p-5">
            <h2 className="font-semibold text-gray-900 mb-4">Profile Summary</h2>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center text-primary font-bold">
                {initials}
              </div>
              <div>
                <p className="font-semibold text-gray-900">{user.name}</p>
                <p className="text-sm text-gray-500">{user.email}</p>
              </div>
            </div>
            <Link href="/profile" className="block text-center w-full border border-gray-200 text-gray-700 py-2 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors">
              View Profile
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
